import java.beans.JavaBean;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

@JavaBean
public class ProbabilityGenerator<T> {

    // A list of all possible outcomes.
    private final List<T> outcomes;

    // A map of probabilities for each outcome. The probabilities must sum to 100.0.
    private final Map<T, Double> probabilities;

    // A map of occurrence counts for each outcome.
    private final Map<T, Integer> occurrenceCounts;

    public ProbabilityGenerator(List<T> outcomes, Map<T, Integer> probabilities) {
        // Initialize the fields.
        this.outcomes = outcomes;
        this.probabilities = new HashMap<>();
        this.occurrenceCounts = new HashMap<>();

        // Validate the probabilities.
        double totalProbability = 0.0;
        for (T outcome : outcomes) {
            totalProbability += probabilities.get(outcome);
        }
        if (totalProbability != 100.0) {
            throw new IllegalArgumentException("The probabilities must sum to 100.0.");
        }

        // Initialize the probabilities map.
        for (T outcome : outcomes) {
            this.probabilities.put(outcome, probabilities.get(outcome) / 100.0);
            this.occurrenceCounts.put(outcome, 0);
        }
    }

    public T generateOutcome() {
        // Create a random number between 0.0 and 1.0.
        Random random = new Random();
        double randomNumber = random.nextDouble();

        // Calculate the total probability.
        double totalProbability = 0.0;
        for (T outcome : outcomes) {
            totalProbability += probabilities.get(outcome);
        }

        // Find the first outcome whose probability is greater than or equal to the random number.
        double currentProbability = 0.0;
        for (T outcome : outcomes) {
            currentProbability += probabilities.get(outcome);
            if (randomNumber <= currentProbability) {
                occurrenceCounts.put(outcome, occurrenceCounts.get(outcome) + 1);
                return outcome;
            }
        }

        // If no outcome is found, then return the first outcome in the list.
        return outcomes.get(0);
    }

    public Map<T, Integer> getOccurrenceCounts() {
        return occurrenceCounts;
    }
}
