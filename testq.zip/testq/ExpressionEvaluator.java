import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class ExpressionEvaluator {

    private final ExecutorService executorService;
    private final LinkedBlockingQueue<String> expressionsQueue;

    public ExpressionEvaluator() {
        // Create a thread pool with 50 threads.
        executorService = Executors.newFixedThreadPool(50);

        // Create a queue to buffer the incoming expressions.
        expressionsQueue = new LinkedBlockingQueue<>();
    }

    public void evaluate(String expression) {
        // Add the expression to the queue.
        expressionsQueue.add(expression);
    }

    public void start() {
        // Start a thread in the thread pool for each expression in the queue.
        executorService.submit(() -> {
            while (true) {
                // Get the next expression from the queue.
                String expression="";
                try {
                    expression = expressionsQueue.poll(100, TimeUnit.MILLISECONDS);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                // If there are no more expressions in the queue, then break out of the loop.
                if (expression == null) {
                    break;
                }

                // Evaluate the expression using the Web API.
                String result = evaluateExpressionUsingWebAPI(expression);

                // Display the result of the expression on the console.
                System.out.println(result);
            }
        });
    }

    public void stop() {
        // Shutdown the thread pool.
        executorService.shutdown();
    }

    private String evaluateExpressionUsingWebAPI(String expression) {
        // Replace this with your own API key for the Google Calculator API.
        String apiKey = "";
        String url = "https://www.googleapis.com/calculator/v1/calculate?expression=" + expression + "&key=" + apiKey;

        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String response = reader.readLine();

            reader.close();
            connection.disconnect();

            return response;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
