import java.util.List;
import java.util.Map;

public class Main {

    public static void main(String[] args) {
        List<Integer> outcomes = List.of(1, 2);
        Map<Integer, Integer> percentages = Map.of(1, 35, 2, 65);

        ProbabilityGenerator<Integer> probabilityGenerator = new ProbabilityGenerator<>(outcomes, percentages);

        for (int i = 0; i < 1000; i++) {
            probabilityGenerator.generateOutcome();
        }

        Map<Integer, Integer> occurrenceCounts = probabilityGenerator.getOccurrenceCounts();

        System.out.println("Outcome 1: " + occurrenceCounts.get(1));
        System.out.println("Outcome 2: " + occurrenceCounts.get(2));

        ExpressionEvaluator evaluator = new ExpressionEvaluator();

        // Start the evaluator.
        evaluator.start();

        // Submit some expressions to the evaluator.
        evaluator.evaluate("1 + 2");
        evaluator.evaluate("3 * 4");
        evaluator.evaluate("5 / 6");



        // Stop the evaluator.
        evaluator.stop();
    }
}
