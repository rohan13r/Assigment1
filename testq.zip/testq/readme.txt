Probability Generator and Expression Evaluator

This program allows you to generate outcomes based on defined probabilities and evaluate mathematical expressions using a web API.

Prerequisites

Java Development Kit (JDK)
Setup

Clone or download the project repository from GitHub to your local machine.
Open a command prompt or terminal.
Navigate to the project directory using the cd command.
Running the Probability Generator

Open the Main.java file in the src folder.
Ensure that you have defined the outcomes and percentages in the Main class.
Run the program by executing the following command:
java Main
The program will generate outcomes based on the specified probabilities and display the occurrence counts for each outcome.

Running the Expression Evaluator

Open the Main.java file in the src folder.
Make sure you have defined and submitted some expressions to the evaluator using the evaluate method.
Run the program by executing the following command:
java Main
The program will start the evaluator, submit the provided expressions, and display the results obtained from the web API.

Key Notes

Ensure that you have the necessary API key for the web API if required. You need to set the apiKey variable in the ExpressionEvaluator class.
Be aware that this code is just a template, and you may need to make modifications to the ProbabilityGenerator and ExpressionEvaluator classes to suit your specific use case.
Handle exceptions appropriately when running the program, especially in the case of API requests.
Remember to have an internet connection active when running the Expression Evaluator since it relies on web API calls.